<?php

namespace app\user\controller;

use think\Controller;
use think\Request;
use think\Db;

class Index extends Controller{

	private $memcache;

	public function initialize(){
		$this->memcache = new \Memcache;
		$this->memcache->connect('127.0.0.1',11211);
	}

	public function logout(){
		session('mobile',null);
		return redirect('/login');
	}

	public function login(Request $request){
		if($request->isPost()){
            $data = $request->param();

            $validate = new \app\user\validate\User();

            if(!$validate->check($data)){
                return $this->error($validate->getError());
            }

            $user['mobile'] = $request->param('mobile');
            $user['password'] = md5($request->param('password'));

			if($password = $this->memcache->get($user['mobile'])){
				if($password==$user['password']){
					session('mobile',$user['mobile']);
                    $this->memcache->set($user['mobile'],$user['password'] ); 
					return redirect('/');
				}else{
					return $this->error('密码错误');
				}
			}

			$res = Db::name('user')->where('mobile',$user['mobile'])->find();

			if($res){
				
				if($res['password']==$user['password'] ){
					 session('mobile',$user['mobile']);
                     $this->memcache->set($user['mobile'],$user['password'] );				
					return redirect('/');
				}

			}else{
			    return $this->error('用户不存在');
			}


		}else{
			return view('login');
		}
	}

	public function register(Request $request){

		if($request->isPost()){
			$data = $request->param();

			$validate = new \app\user\validate\User();
		
			if(!$validate->check($data)){
				return $this->error($validate->getError());
			}		
			
			$user['mobile'] = $request->param('mobile');		
			$user['password'] = md5($request->param('password'));		
	
			$ret = Db::name('user')->where('mobile',$user['mobile'])->find();
			
			if($ret){
				return $this->error('用户已经存在');
			}			
	
			$res = Db::name('user')->insert($user);

			if($res){
				session('mobile',$user['mobile']);
				$this->memcache->set($user['mobile'],$user['password'] );			
				return $this->redirect('/');
			}
	

		}else{
			return view('register');
		}
	}
}
