<?php
namespace app\index\controller;

use think\Request;
use think\Controller;
use think\Db;
use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;

class Index extends Controller{

	private $start_time = 1585899574;
	private $redis;

	public function initialize (){
		$this->redis = new \Redis();
		$this->redis->connect('127.0.0.1',6379);	
	}

    public function index()
    {
		return view('index');
    }
	public function getTime(){
	//	if(!session('mobile')){
	//		return json(['status'=>'fail','msg'=>'先去登录']);;
	//	}
		$time = $this->start_time-time();
		return json(['time'=>$time]);	
	}


	public function getPath(Request  $request){

		if(!session('mobile')){
            return json(['status'=>'fail','msg'=>'先去登录']);
        }
		$now_time = time();
		if($now_time<$this->start_time){
			return json(['status'=>'fail','msg'=>'秒杀还没有开始']);
		}

		$ip = $request->server()['HTTP_X_FORWARDED_FOR'];
	
		if($this->redis->exists($ip)){
			if($this->redis->get($ip)>2){
				return json(['status'=>'fail','msg'=>'ip请求过多']);
			}			
			$this->redis->incr($ip);
		}else{		
			$this->redis->set($ip,1);		
		}
		$url = md5(session('mobile').$request->param('id'));
		
		$this->redis->set($url,1);  //1 为未访问  0访问 	
		// 这个地方 把地址 存到redis
		return json(['status'=>'success','url'=>$url]);	
	}

	public function order(Request $request){
		$url = $request->param('url');
		$id = $request->param('id');
		//http://www.lampol.vip/go/905635236f688eb6f0725a9512ced822/order/?id=1
		//echo $url.'===='.$id;
		
		if(!$this->redis->exists($url)){
			return json(['status'=>'fail','msg'=>'请求地址不合法']);
		}
		
		if(!$this->redis->get($url)){
			return json(['status'=>'fail','msg'=>'秒杀已经参加过了吧']);
		}		
		$this->redis->set($url,0);				
		
		$mobile = session('mobile');		
	//	$mobile = '13888888888';
		//  实际业务处理
		/**
		try{	
			Db::startTrans();
			$res = Db::name('goods')->where('id',$id)->setDec('num');
			$num = Db::name('goods')->where('id',$id)->value('num'); 		
	
			if($num<0){
				return json(['status'=>'fail','msg'=>'秒杀失败']);
			}
			
			//$res = Db::name('goods')->where('id',$id)->setDec('num');		
			// $res = Db::name('orders')->insert(['mobile'=>$mobile,'goods_id'=>$id]);
		
			//$res = Db::name('goods')->where('id',$id)->setDec('num');
	
			if($res){
			  //  Db::name('goods')->where('id',$id)->setDec('num');		
				Db::name('orders')->insert(['mobile'=>$mobile,'goods_id'=>$id]);
				Db::commit();
				return json(['status'=>'success','msg'=>'秒杀成功']);
			}
	
		}catch(\Exception $e){
			Db::rollback();
		}
		**/	

		$goods_id = $this->redis->lpop('goods_id');
		
		if($goods_id){
			$this->redis->lpush('orders',$mobile.'=='.$goods_id);
			$this->sendOrder(json_encode(['mobile'=>$mobile,'goods_id'=>$goods_id]));
				
			return json(['status'=>'success','msg'=>'秒杀成功']);
		}else{
			return json(['status'=>'fail','msg'=>'秒杀失败']);
		}
		
	}	

	public function sendOrder($data){
		$connection = new AMQPStreamConnection(config('rabbitmq.rabbit-server'),config('rabbitmq.rabbit-port'), config('rabbitmq.rabbit-user'), config('rabbitmq.rabbit-password'));
		$channel = $connection->channel();
		
		$queue_name = config('rabbitmq.rabbit-queue');
		
		$channel->queue_declare($queue_name, false, false, false, false);
		
		$msg = new AMQPMessage($data);
		$channel->basic_publish($msg,'',$queue_name);
		
		
		$channel->close();
		$connection->close();		
	}

}
