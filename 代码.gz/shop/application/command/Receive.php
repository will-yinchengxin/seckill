<?php

namespace app\command;

use think\console\Command;
use think\console\Input;
use think\console\Output;
use PhpAmqpLib\Connection\AMQPStreamConnection;
use think\Db;

class Receive extends Command
{
    protected function configure()
    {
        // 指令配置
        $this->setName('queue_recv');
        // 设置参数
        
    }

    protected function execute(Input $input, Output $output)
    {
    	// 指令输出
    	//$output->writeln('jhjjjjjjjj');
		$connection = new AMQPStreamConnection(config('rabbitmq.rabbit-server'),config('rabbitmq.rabbit-port'), config('rabbitmq.rabbit-user'), config('rabbitmq.rabbit-password'));
        $channel = $connection->channel();

        $queue_name = config('rabbitmq.rabbit-queue');	
	
		$channel->queue_declare($queue_name, false, false, false, false);
		
		
		$callback = function ($msg) {
		  $data = json_decode($msg->body,true);
		  Db::name('orders')->insert($data);
		};
		
		$channel->basic_consume($queue_name, '', false, true, false, false, $callback);
		
		while ($channel->is_consuming()) {
		    $channel->wait();
		}
		
		$channel->close ();
		$connection->close ();
		
    }
}
