<?php /*a:1:{s:53:"/home/www/shop/application/user/view/index/login.html";i:1584625170;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>秒杀用户登录</title>
<link rel="stylesheet" href="http://cdn.lampol.vip/css/style.css">
</head>

<body>
    <div class="content">
        <div class="form sign-in">
            <h2>秒杀用户登录</h2>
			<form action="login" method="post">
				<?php echo token(); ?>
				 <label>
                    <span>用户名</span>
                    <input type="text" name="mobile" />
                </label>
                <label>
                    <span>密码</span>
                    <input type="password" name="password" />
                </label>
                <button type="submit" class="submit">登 录</button>
			</form>
        </div>
    </div>
</body>

</html>
