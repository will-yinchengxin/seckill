<?php /*a:1:{s:54:"/home/www/shop/application/index/view/index/index.html";i:1585298919;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
	<meta charset="utf-8">
	<title>秒杀</title>
	<link href="http://cdn.lampol.vip/css/timeTo.css" type="text/css" rel="stylesheet"/>
	<link href="http://cdn.lampol.vip/css/style.css" type="text/css" rel="stylesheet"/>
	<script src="http://cdn.lampol.vip/js/jquery.min.js"></script>
	<script src="http://cdn.lampol.vip/js/jquery.time-to.min.js"></script>
</head>

<body>
	<div id="box">
		<img class="ms_pic"  src="http://cdn.lampol.vip/img/huawei.jpg" />
		<div id="ms"> </div>
	</div>
	
	<div  class="countdown" id="countdown"></div>
</body>

<script>

$.get('getTime',function(res){
		
	if(res.status=='fail'){
		alert(res.msg);
		return;
	}
	tt = res.time;	

	if(tt<0){
    	tt='stop';
	}


	$('#countdown').timeTo(tt,function(){
    	$('#ms').append('<img id="ms_start"  class="ms_start"  src="http://cdn.lampol.vip/img/start.jpg" />');
	});

})

$('#ms').on('click','img',function(){
	if(localStorage.getItem('clk')==null){
		console.log('start');	
		localStorage.setItem('clk',true);

		$.get('getPath',{id:1},function(res){
			if(res.status=='success'){
				//这里开始请求  秒杀接口  带着 res.url
				$.get('/go/'+res.url+'/order/',{id:1},function(res){
						if(res.status=='success'){
							alert(res.msg);
						}else{
							alert(res.msg);
						}
					
				});
					
			}
		});

	}else{
		$('#ms').html('');
		alert('秒杀结束');	
	}

});




</script>
</html>
