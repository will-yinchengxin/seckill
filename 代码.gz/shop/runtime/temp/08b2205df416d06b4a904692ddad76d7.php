<?php /*a:1:{s:56:"/home/www/shop/application/user/view/index/register.html";i:1583847948;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>秒杀-用户注册</title>
<link rel="stylesheet" href="/static/css/style.css">
</head>
<body>
    <div class="content">
        <div class="form sign-in">
            <h2>秒杀-用户注册</h2>
			<form action="register" method="post">
				<?php echo token(); ?>
				<label>
                    <span>用户名</span>
                    <input type="text" name="mobile" />
                </label>
                <label>
                    <span>密码</span>
                    <input type="password" name="password" />
                </label>
                <button type="submit" class="submit">注册</button>
			</form>
        </div>
    </div>
</body>

</html>
