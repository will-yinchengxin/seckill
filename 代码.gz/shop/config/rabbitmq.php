<?php

return [
	'rabbit-server'=>'120.27.3.166',
	'rabbit-port'=>5672,
	'rabbit-user'=>'lampol',
	'rabbit-password'=>'123456',
	'rabbit-queue'=>'shop',

];
