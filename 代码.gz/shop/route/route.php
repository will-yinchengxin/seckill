<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006~2018 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------

Route::get('/','index/Index/index');//->middleware('Login');
Route::get('getTime','index/Index/getTime');//->middleware('Login');
Route::get('getPath','index/Index/getPath');//->middleware('Login');
Route::get('go/:url/order','index/Index/order');//->middleware('Login');
Route::rule('login','user/Index/login','GET|POST');
Route::rule('register','user/Index/register','GET|POST');
Route::get('logout','user/Index/logout');
